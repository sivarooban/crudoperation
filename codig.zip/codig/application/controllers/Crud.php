<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
        parent::__construct();
        $this->load->model('Crud1');
		 $this->load->helper('url');
		  $this->load->library('session');
    }
	public function index(){		
		$result    = $this->Crud1->cruddetail();
		/* echo "<pre>";
		print_r($result);
		echo "</pre>";  */
		$data['result'] = $result;
		$this->load->view('crud',$data);
	}
	public function add(){	
		$email_id     = $this->input->post('email_id');
		$phone_number = $this->input->post('phone_number');
		if($this->Crud1->cruddetail_check_email($email_id)){
			$this->session->set_flashdata('msg', 'Email id already exist');
		}else if($this->Crud1->cruddetail_check_phone($phone_number)){
			$this->session->set_flashdata('msg', 'Phone Number already exist');
		}else{
			$form_data = array(
				'emp_name'     => $this->input->post('emp_name'),
				'email_id'     => $this->input->post('email_id'),
				'phone_number' => $this->input->post('phone_number'),
				'dob'          => $this->input->post('dob')
			);
			if($this->Crud1->cruddetail_insert($form_data)){
				$this->session->set_flashdata('msg', 'data successfully added');
			}
		}
		redirect(base_url(),"refresh");	
	}
	public function edit(){	
		$id                 = $this->input->post('id');		
		$data['result_set'] = $this->Crud1->cruddetail_getrecord($id);
		$this->load->view('crud_edit',$data);	
	}
	public function update(){
		$id = $this->input->post('id');
		$form_data = array(			
			'emp_name'     => $this->input->post('emp_name'),
			'email_id'     => $this->input->post('email_id'),
			'phone_number' => $this->input->post('phone_number'),
			'dob'          => $this->input->post('dob')
		);		
		if($this->Crud1->cruddetail_update($form_data,$id)){
			$this->session->set_flashdata('msg', 'record updated successfully');
		}		
		redirect(base_url(),"refresh");	
	}
}
